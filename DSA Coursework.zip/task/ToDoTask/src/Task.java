import java.time.LocalDate;

public record Task(String task, String allocatedTo, String designation,
                   LocalDate dueDate) {

	public LocalDate getDueDate() {
		return dueDate;
	}

	public String getTask(){
		return task;
	}

	public String getAllocatedTo(){
		return allocatedTo;
	}

	public String getDesignation(){
		return designation;
	}

	@Override
	public String toString() {
		return String.format("| %-45s | %-25s | %-10s | ", task, allocatedTo + ", " + designation, dueDate.toString());
	}
}
