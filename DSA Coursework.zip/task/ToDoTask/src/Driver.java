import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Driver {

	static ArrayList<Task> todo = new ArrayList<>();
	static ArrayList<Task> doing = new ArrayList<>();
	static ArrayList<Task> done = new ArrayList<>();

	static Scanner input = new Scanner(System.in);


	public static void mainMenu() {
		System.out.println();
		System.out.println("-------------------------------------------");
		System.out.println("1. Create New To Do Task");
		System.out.println("2. View Lists");
		System.out.println("3. Move Task From To Do List To Doing List");
		System.out.println("4. Move Task From Doing List To Done List");
		System.out.println("5. Load Data From File");
		System.out.println("6. Save Data To File");
		System.out.println("7. Exit");
		System.out.println("-------------------------------------------");
		System.out.print("Your Choice: ");
	}

	public static void createNewTask() {
		String description = getString("Enter Description Of New Task: ");
		String allocatedTo = getString("Allocated To: ");
		String designation = getString("Designation: ");
		LocalDate dueDate = getDate();
		Task newTask = new Task(description, allocatedTo, designation, dueDate);
		todo.add(newTask);
		System.out.println();
		System.out.println("Task Created Successfully!");
	}

	public static void displayMenu() {
		System.out.println();
		System.out.println("-------------------------------------------");
		System.out.println("1. View To Do List");
		System.out.println("2. View Doing List");
		System.out.println("3. View Done List");
		System.out.println("4. Back");
		System.out.println("-------------------------------------------");
		System.out.println();
		System.out.print("Your Choice: ");
		String opt = input.nextLine();
		System.out.println();
		switch (opt) {
			case "1" -> display(todo, "Viewing To Do List");
			case "2" -> display(doing, "Viewing Doing List");
			case "3" -> display(done, "Viewing Done List");
			case "4" -> {
				display(todo, "Viewing To Do List");
				System.out.println();
				display(doing, "Viewing Doing List");
				System.out.println();
				display(done, "Viewing Done List");
			}
			default -> {
				System.out.println("Error: Invalid choice");
				displayMenu();
			}
		}
	}

	public static void display(ArrayList<Task> list, String msg) {
		System.out.println(msg);
		System.out.println("-------------------");
		System.out.println("-----------------------------------------------------------------------------------------------------------------------");
		System.out.printf("| %-3s | %-45s | %-25s | %-10s | %-20s |%n", "No.", "Task", "Allocated To", "Due Date", "Status");
		System.out.println("-----------------------------------------------------------------------------------------------------------------------");

		int counter = 1;
		for (Task task : list) {
			long days = ChronoUnit.DAYS.between(LocalDate.now(), task.getDueDate());
			String status;
			if (days == 0) {
				status = "Due today";
			} else if (days < 0) {
				days = days * (-1);
				status = "Over due by " + days + " days";
			} else {
				status = days + " days left";
			}

			System.out.println(String.format("| %-3s ", counter) + task + String.format("%-20s |", status));
			counter++;
		}

		System.out.println("-----------------------------------------------------------------------------------------------------------------------");

	}

	public static void moveToDoing() {
		if (todo.size() == 0) {
			System.out.println("No Task In To Do List");
			return;
		}

		display(todo, "Move from to do list to doing list");
		System.out.print("Please enter index of task you wish to move: ");
		try {
			int index = Integer.parseInt(input.nextLine());
			if (index > 0 && index <= todo.size()) {
				System.out.println("Removing Task ...");
				Task task = todo.remove(index - 1);
				System.out.println("------------------------------------------------------------------------------------------");
				System.out.printf("| %-45s | %-25s | %-10s |%n", "Task", "Allocated To", "Due Date");
				System.out.println("------------------------------------------------------------------------------------------");
				System.out.printf("| %-45s | %-25s | %-10s |%n", task.getTask(), task.getAllocatedTo() + ", " + task.getDesignation(), task.getDueDate());
				System.out.println("------------------------------------------------------------------------------------------");
				System.out.println("Moving to doing list ...");
				doing.add(task);
				display(doing,"Doing List");
			} else {
				throw new NumberFormatException();
			}
		} catch (NumberFormatException exp) {
			System.out.println();
			System.out.println("Error: Invalid Index");
		}
	}

	public static void moveToDone() {
		if (todo.size() == 0) {
			System.out.println("No Task In Doing List");
			return;
		}

		display(doing, "Move from to doing list to done list");
		System.out.print("Please enter index of task you wish to move: ");
		try {
			int index = Integer.parseInt(input.nextLine());
			if (index > 0 && index <= doing.size()) {
				System.out.println("Removing Task ...");
				Task task = doing.remove(index - 1);
				System.out.println("------------------------------------------------------------------------------------------");
				System.out.printf("| %-45s | %-25s | %-10s |%n", "Task", "Allocated To", "Due Date");
				System.out.println("------------------------------------------------------------------------------------------");
				System.out.printf("| %-45s | %-25s | %-10s |%n", task.getTask(), task.getAllocatedTo() + ", " + task.getDesignation(), task.getDueDate());
				System.out.println("------------------------------------------------------------------------------------------");
				System.out.println("Moving to done list ...");
				done.add(task);
				display(done,"Done List");
			} else {
				throw new NumberFormatException();
			}
		} catch (NumberFormatException exp) {
			System.out.println();
			System.out.println("Error: Invalid Index");
		}
	}

	public static void loadData() {
		String fileName = getString("Enter File Name To Load Data: ");
		try {
			File file = new File(fileName);
			Scanner fileScanner = new Scanner(file);
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				String[] tokens = line.split(",");
				if (tokens.length == 5) {
					if (!tokens[0].equals("") && !tokens[1].equals("") && !tokens[2].equals("")) {
						try {
							LocalDate dueDate = LocalDate.parse(tokens[3]);

							Task newTask = new Task(tokens[0], tokens[1], tokens[2], dueDate);

							switch (tokens[4].toLowerCase(Locale.ROOT)) {
								case "to do" -> todo.add(newTask);
								case "doing" -> doing.add(newTask);
								case "done" -> done.add(newTask);
							}

						} catch (DateTimeParseException ignored) {
						}
					}
				}
			}
			System.out.println();
			System.out.println("Data Load Successfully!");
		} catch (FileNotFoundException e) {
			System.out.println();
			System.out.println("Error: File Not Found");
		}
	}

	public static void saveDate() {
		String fileName = getString("Enter File Name To Save Data: ");
		File file = new File(fileName);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				System.out.println();
				System.out.println("Error: Can Not Create File");
				return;
			}
		}

		try {
			FileWriter writer = new FileWriter(file);
			writer.write("");
			for (Task task : todo) {
				writer.append(task.getTask()).append(",").append(task.allocatedTo()).append(",").append(task.getDesignation()).append(",").append(String.valueOf(task.getDueDate())).append(",").append("to do").append("\n");
			}
			for (Task task : doing) {
				writer.append(task.getTask()).append(",").append(task.allocatedTo()).append(",").append(task.getDesignation()).append(",").append(String.valueOf(task.getDueDate())).append(",").append("doing").append("\n");
			}
			for (Task task : done) {
				writer.append(task.getTask()).append(",").append(task.allocatedTo()).append(",").append(task.getDesignation()).append(",").append(String.valueOf(task.getDueDate())).append(",").append("done").append("\n");
			}
			System.out.println();
			System.out.println("Data Saved Successfully!");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static LocalDate getDate() {
		String strDate = getString("Enter Due Date (YYYY-MM-DD): ");
		try {
			return LocalDate.parse(strDate);
		} catch (DateTimeParseException exp) {
			System.out.println();
			System.out.println("Error: Invalid Date Format");
			System.out.println();
		}
		return getDate();
	}

	public static String getString(String msg) {
		System.out.print(msg);
		String str = input.nextLine();
		if (str.equals("")) {
			System.out.println();
			System.out.println("Error: Value Must Not Be Null");
			System.out.println();
			return getString(msg);
		}
		return str;
	}

	public static void main(String[] args) {
		do {
			mainMenu();
			String opt = input.nextLine();
			System.out.println();
			switch (opt) {
				case "1" -> createNewTask();
				case "2" -> displayMenu();
				case "3" -> moveToDoing();
				case "4" -> moveToDone();
				case "5" -> loadData();
				case "6" -> saveDate();
				case "7" -> System.exit(0);
				default -> System.out.println("Error: Invalid choice");
			}
		} while (true);
	}
}
